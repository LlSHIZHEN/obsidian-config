export const ja = {};
